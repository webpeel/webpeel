"""Version information for WebPeel SDK."""

__version__ = "0.1.0"
